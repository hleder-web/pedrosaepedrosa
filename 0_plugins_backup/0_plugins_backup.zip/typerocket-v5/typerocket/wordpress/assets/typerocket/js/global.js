window.TypeRocket={httpCallbacks:[],repeaterCallbacks:[],lastSubmittedForm:!1,redactor:{extend:{},lang:"en",plugins:[],override:{}},builderCallbacks:[]};
