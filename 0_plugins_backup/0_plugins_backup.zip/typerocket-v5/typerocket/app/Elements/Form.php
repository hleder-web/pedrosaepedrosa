<?php
namespace App\Elements;

use TypeRocket\Elements\BaseForm;

class Form extends BaseForm
{
}